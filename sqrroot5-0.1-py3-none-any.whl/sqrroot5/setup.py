from setuptools import setup
setup(name="sqrroot5",
      version="0.1",
      description="calculate square root of 5 in 0 seconds. POV: just for fun lol",
      Long_description="same as above lol",
      author="Dhruvin Dholakia",
      packages=['sqrroot5'],
      install_requires=[])